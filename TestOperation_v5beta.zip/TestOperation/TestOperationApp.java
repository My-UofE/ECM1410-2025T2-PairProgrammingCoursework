public class TestOperationApp {
    public static void main(String[] args) {
        System.out.println("######## Running TestOperationApp...");
        Test01PlayerBasic.main((String[]) null);
        Test02PlayerExceptions.main((String[]) null);
        Test03LeagueBasic.main((String[]) null);
        Test04LeagueExceptions.main((String[]) null);
        Test05LeagueInvitations.main((String[]) null);
        Test06DayResultsDiceRoll.main((String[]) null);
        Test07DayResultsWordMaster.main((String[]) null);
        System.out.println("######## Finished TestOperationApp...");
        }
}